open folder in sublime
run recommedation.py 

https://github.com/codeheroku/Introduction-to-Machine-Learning/blob/master/Building%20a%20Movie%20Recommendation%20Engine/Assignment%20Solution.ipynb